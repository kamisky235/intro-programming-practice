cpp
#include <iostream>
using namespace std;
int main() {
cout << "Hello, GitHub! My name is [Your Name]" << endl;
return 0;
}