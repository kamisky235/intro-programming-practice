// ========================================================
====
// PROGRAM 5: DAY OF WEEK (C VERSION)
// Demonstrates switch-case
// ========================================================
====

#include <stdio.h>
int main() {
// Declare a variable for the day number
int day;
// Prompt the user for a day number
printf("Enter day number (1-7): ");
scanf("%d", &day);
// Switch on the day number
switch (day) {
case 1:
printf("Monday\n");
break; // break exits the switch
case 2:
printf("Tuesday\n");
break;
case 3:
printf("Wednesday\n");
break;
case 4:
printf("Thursday\n");
break;
case 5:
printf("Friday\n");
break;
case 6:
printf("Saturday\n");
break;


case 7:
printf("Sunday\n");
break;
default:
printf("Invalid day number!\n");
break;
}
return 0;
}