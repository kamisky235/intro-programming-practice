// ============================================================
// ACTIVITY 1: SUM OF FIRST N NATURAL NUMBERS (C VERSION)
// Learning Outcome: Apply a for loop to iterate over a range
// ============================================================

// Include the standard input/output library for printf and scanf
#include <stdio.h>

// The main function - where the program starts running
int main() {

// Declare an integer variable to store the user's input (N)
// This will hold the upper limit of our sum (e.g., if N=5, sum 1+2+3+4+5)
int n;

// Declare an integer variable to store the running total
// We initialise it to 0 because we haven't added anything yet
int sum = 0;

// Display a prompt asking the user to enter a number
// printf is the C equivalent of cout in C++
printf("Enter a positive number (N): ");

// Read the user's input from the keyboard and store it in 'n'
// scanf requires the address of the variable (&n) so it knows where to store the value
// %d is the format specifier for integers
scanf("%d", &n);

// Start a for loop with three parts separated by semicolons:
// Part 1: int i = 1; -> Initialisation: start counting from 1
// Part 2: i <= n; -> Condition: keep looping while i is less than or equal to n
// Part 3: i++ -> Increment: increase i by 1 after each iteration
for (int i = 1; i <= n; i++) {

// Add the current value of i to the running total
// This is equivalent to: sum = sum + i
sum += i;

} // End of for loop - execution returns to the condition check

// Display the final result to the user
// printf uses %d for integer, \n for newline
printf("The sum of numbers from 1 to %d is: %d\n", n, sum);

// Return 0 to signal that the program ended successfully

Page 3 of 12

return 0;
}